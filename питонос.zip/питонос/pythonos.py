# pythonos.py (ВОССТАНОВЛЕННАЯ ПОЛНАЯ ЦВЕТНАЯ ВЕРСИЯ С MATRIX)

import os
import time
import random

# --- ЦВЕТА КОНСОЛИ (ANSI ESCAPE CODES) ---
class Colors:
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    
    COLOR_MAP = {
        'red': RED, 'green': GREEN, 'yellow': YELLOW, 'blue': BLUE, 
        'magenta': MAGENTA, 'cyan': CYAN, 'white': WHITE, 'black': BLACK
    }

class PythonOS:
    def __init__(self):
        self.cwd = "/"  # Current Working Directory
        self.current_color = Colors.GREEN
        self.file_system = {
            "/": {
                "welcome.txt": "Welcome back to PythonOS CLI! Type 'help' for commands.",
                "about.txt": "PythonOS 1.0 (CLI) - Matrix Edition.",
                "config": {"color.conf": "green"},
                "bin": {},
                "users": {"guest": {}}
            }
        }
    
    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def print_output(self, text):
        """Вывод текста с текущим цветом."""
        print(f"{self.current_color}{text}{Colors.RESET}")

    def run(self):
        """Главный цикл консольной ОС."""
        self.clear_screen()
        self.print_output(f"{Colors.BOLD}PythonOS 1.0 (CLI) started. (Type 'help'){Colors.RESET}")
        
        while True:
            try:
                # Ввод с текущим цветом
                command = input(f"{self.current_color}PythonOS:{self.cwd}> {Colors.RESET}").strip()
                if not command:
                    continue
                
                parts = command.split()
                cmd = parts[0].lower()
                args = parts[1:]

                if cmd == 'exit' or cmd == 'shutdown':
                    self.print_output("Returning to PyOS 2.0 GUI...")
                    time.sleep(0.5)
                    return "pyos_gui"
                
                elif cmd == 'reboot' or cmd == 'bios':
                    self.print_output("Rebooting to Boot Menu...")
                    time.sleep(1)
                    return "bootmenu"

                elif cmd == 'help':
                    self.show_help()

                elif cmd == 'ls':
                    self.list_files(self.cwd)
                    
                elif cmd == 'cat' and args:
                    self.cat_file(args[0])

                elif cmd == 'cd' and args:
                    self.change_directory(args[0])
                
                elif cmd == 'mkdir' and args:
                    self.make_directory(args[0])
                
                elif cmd == 'clear':
                    self.clear_screen()
                
                # ⭐ КОМАНДА MATRIX
                elif cmd == 'matrix':
                    self.run_matrix_effect()
                
                # ⭐ КОМАНДА COLOR
                elif cmd == 'color' and args:
                    self.change_color(args[0])
                
                elif cmd == 'gui':
                    self.print_output("Starting PythonOS 2.0 GUI...")
                    time.sleep(1)
                    return "pyos_gui"

                elif cmd == 'echo' and args:
                    self.print_output(" ".join(args))
                    
                else:
                    self.print_output(f"Error: Unknown command '{cmd}'. Type 'help'.")
                    
            except EOFError:
                self.print_output("Exit signal received. Returning to GUI.")
                return "pyos_gui"
            except Exception as e:
                self.print_output(f"An unexpected error occurred: {e}")
                
    # --- НОВЫЕ МЕТОДЫ ---
    
    def run_matrix_effect(self):
        """Демонстрация эффекта Матрицы."""
        self.clear_screen()
        self.print_output(f"{Colors.GREEN}{Colors.BOLD}Wake up, Neo...{Colors.RESET}")
        
        chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*'
        
        try:
            for _ in range(50): 
                line = ''.join(random.choice(chars) for _ in range(os.get_terminal_size().columns))
                print(f"{Colors.GREEN}{line}{Colors.RESET}")
                time.sleep(0.05)
        except AttributeError:
             self.print_output("Terminal size error. Matrix effect skipped. (Run in full terminal)")
        except KeyboardInterrupt:
             self.print_output("\nMatrix effect interrupted.")
        
        self.print_output("Press Enter to continue...")
        try:
             input()
        except EOFError:
             pass
        self.clear_screen()
        
    def change_color(self, color_name):
        """Меняет цвет шрифта консоли."""
        color_name = color_name.lower()
        if color_name in Colors.COLOR_MAP:
            self.current_color = Colors.COLOR_MAP[color_name]
            self.print_output(f"Color changed to {color_name}.")
        else:
            self.print_output(f"Error: Unknown color '{color_name}'. Available: {', '.join(Colors.COLOR_MAP.keys())}")

    # --- ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ---

    def get_dir_content(self, path):
        if path == "/":
            return self.file_system["/"]
        self.print_output("Error: Directory navigation is limited to '/' in this demo.")
        return self.file_system["/"]

    def show_help(self):
        self.print_output("\n--- PythonOS Commands ---")
        self.print_output("  help         - Show this help message.")
        self.print_output("  ls           - List files and directories.")
        self.print_output("  cat [file]   - Display file content.")
        self.print_output("  cd [dir]     - Change directory (only '/' supported).")
        self.print_output("  mkdir [dir]  - Create a new directory (only in root).")
        self.print_output("  clear        - Clear the terminal screen.")
        self.print_output("  echo [text]  - Print a message.")
        self.print_output("  color [name] - Change font color (green, blue, etc.).")
        self.print_output("  matrix       - Launch the Matrix falling code effect.")
        self.print_output("  gui          - Switch to PythonOS 2.0 GUI.")
        self.print_output("  reboot/bios  - Reboot to the Boot Menu.")
        self.print_output("  exit/shutdown- Return to PyOS 2.0 GUI.")
        self.print_output("-------------------------\n")

    def list_files(self, path):
        content = self.get_dir_content(path)
        self.print_output(f"Contents of {path}:")
        for name, item in content.items():
            if isinstance(item, dict):
                self.print_output(f"  [DIR] {name}/")
            else:
                self.print_output(f"  [FILE] {name}")

    def cat_file(self, filename):
        content = self.get_dir_content(self.cwd)
        if filename in content and isinstance(content[filename], str):
            self.print_output("\n--- File Content ---")
            self.print_output(content[filename])
            self.print_output("--------------------\n")
        else:
            self.print_output(f"Error: File '{filename}' not found or is a directory.")

    def change_directory(self, dirname):
        if dirname == '/':
            self.cwd = '/'
            return
        self.print_output(f"Error: Directory change functionality is limited to '/' in this demo.")
        
    def make_directory(self, dirname):
        if self.cwd == '/':
            if dirname in self.file_system['/']:
                self.print_output(f"Error: Directory '{dirname}' already exists.")
                return
            self.file_system['/'][dirname] = {}
            self.print_output(f"Directory '{dirname}/' created in /.")
        else:
            self.print_output("Error: mkdir command is limited to the root directory in this demo.")