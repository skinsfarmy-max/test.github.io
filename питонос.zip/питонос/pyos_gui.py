# pyos_gui.py (ФИНАЛЬНАЯ ВЕРСИЯ: Закрытие, Меню Пуск, Файловый менеджер)

import tkinter as tk
from tkinter import messagebox
from tkinter import filedialog
import time
import sys
import os

# --- 1. ВНУТРЕННИЙ ТЕРМИНАЛ (GUITerminal) ---

class GUITerminal:
    def __init__(self, master):
        self.master = master
        self.window = tk.Toplevel(master)
        self.window.title("PyOS Terminal")
        self.window.geometry("800x500")
        
        self.bg_color = "#000000"
        self.fg_color = "#00FF00"
        self.font = ('Consolas', 12)
        
        self.window.config(bg=self.bg_color)
        
        self.command_history = []
        self.history_index = -1
        
        self.setup_ui()
        self.print_welcome()

    def setup_ui(self):
        main_frame = tk.Frame(self.window, bg=self.bg_color)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.output_text = tk.Text(main_frame, bg=self.bg_color, fg=self.fg_color, 
                                   font=self.font, bd=0, wrap='word', insertbackground=self.fg_color)
        self.output_text.pack(fill=tk.BOTH, expand=True)
        self.output_text.config(state=tk.DISABLED) 
        
        input_frame = tk.Frame(main_frame, bg=self.bg_color)
        input_frame.pack(fill=tk.X)
        
        prompt_label = tk.Label(input_frame, text="PyOS@local:~$ ", bg=self.bg_color, fg=self.fg_color, font=self.font)
        prompt_label.pack(side=tk.LEFT)
        
        self.input_entry = tk.Entry(input_frame, bg=self.bg_color, fg=self.fg_color, 
                                    font=self.font, bd=0, insertbackground=self.fg_color)
        self.input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        self.input_entry.bind('<Return>', self.process_command)
        self.input_entry.bind('<Up>', self.show_previous_command)
        self.input_entry.bind('<Down>', self.show_next_command)

        self.input_entry.focus_set()

    def print_welcome(self):
        self.print_output("===============================================")
        self.print_output("Welcome to PyOS 2.0 Internal Terminal (Tkinter)")
        self.print_output("Type 'help' for available commands.")
        self.print_output("===============================================\n")

    def print_output(self, text):
        self.output_text.config(state=tk.NORMAL)
        self.output_text.insert(tk.END, text + "\n")
        self.output_text.config(state=tk.DISABLED)
        self.output_text.see(tk.END) 

    def process_command(self, event):
        command = self.input_entry.get().strip()
        self.input_entry.delete(0, tk.END)
        
        if not command:
            self.print_output("PyOS@local:~$")
            return

        self.print_output(f"PyOS@local:~$ {command}")

        if command not in self.command_history:
            self.command_history.append(command)
        self.history_index = -1 
        
        self.execute_command(command)
    
    def execute_command(self, command):
        parts = command.split()
        cmd = parts[0].lower()
        args = parts[1:]
        
        if cmd == 'help':
            self.print_output("--- Available Commands ---")
            self.print_output("help       - Display this list.")
            self.print_output("echo [text]- Print a message.")
            self.print_output("clear      - Clear the terminal screen.")
            self.print_output("exit       - Close this terminal window.")
            self.print_output("ls         - List basic directories.")
            self.print_output("--------------------------")
        elif cmd == 'echo':
            self.print_output(" ".join(args))
        elif cmd == 'clear':
            self.output_text.config(state=tk.NORMAL)
            self.output_text.delete('1.0', tk.END)
            self.output_text.config(state=tk.DISABLED)
            self.print_welcome()
        elif cmd == 'exit':
            self.window.destroy()
        elif cmd == 'ls':
            self.print_output("/Users  /Documents  /Desktop  /System  /Applications")
        else:
            self.print_output(f"Error: Command not found: {cmd}")

    def show_previous_command(self, event):
        if self.command_history:
            if self.history_index == -1:
                self.history_index = len(self.command_history) - 1
            elif self.history_index > 0:
                self.history_index -= 1
            
            self.input_entry.delete(0, tk.END)
            self.input_entry.insert(0, self.command_history[self.history_index])

    def show_next_command(self, event):
        if self.command_history:
            if self.history_index != -1 and self.history_index < len(self.command_history) - 1:
                self.history_index += 1
                self.input_entry.delete(0, tk.END)
                self.input_entry.insert(0, self.command_history[self.history_index])
            elif self.history_index == len(self.command_history) - 1:
                self.history_index = -1
                self.input_entry.delete(0, tk.END)

# --- 2. ФАЙЛОВЫЙ МЕНЕДЖЕР (FileExplorer) ---

class FileExplorer:
    def __init__(self, master):
        self.window = tk.Toplevel(master)
        self.window.title("File Explorer - /Users")
        self.window.geometry("1000x600")
        
        self.bg_color = "#f0f0f0"
        self.header_bg = "#e0e0e0"
        self.window.config(bg=self.bg_color)
        
        self.current_path = "/Users/Guest"
        self.file_list = ["Desktop", "Documents", "Downloads", "Music", "Pictures", "Videos", "README.txt"]
        
        self.setup_ui()
        
    def setup_ui(self):
        nav_frame = tk.Frame(self.window, bg=self.header_bg, height=40)
        nav_frame.pack(fill=tk.X)
        
        path_label = tk.Label(nav_frame, text="Path:", bg=self.header_bg, font=('Segoe UI', 10, 'bold'))
        path_label.pack(side=tk.LEFT, padx=(10, 5))
        
        self.path_entry = tk.Entry(nav_frame, bd=1, relief="solid", width=80)
        self.path_entry.insert(0, self.current_path)
        self.path_entry.pack(side=tk.LEFT, pady=5)
        
        main_frame = tk.Frame(self.window, bg=self.bg_color)
        main_frame.pack(fill=tk.BOTH, expand=True)

        sidebar = tk.Frame(main_frame, width=200, bg="#e8e8e8", bd=1, relief="solid")
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)

        tk.Label(sidebar, text="Quick Access", bg="#dcdcdc", font=('Segoe UI', 10, 'bold')).pack(fill='x', pady=(5, 0))
        for item in ["Desktop", "Documents", "This PC", "Network"]:
             tk.Button(sidebar, text=f"📁 {item}", anchor='w', bd=0, bg="#e8e8e8", command=lambda i=item: self.show_notification(f"Folder: {i}")).pack(fill='x', padx=5)

        content_frame = tk.Frame(main_frame, bg="white", padx=10, pady=10)
        content_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        tk.Label(content_frame, text=f"Contents of {self.current_path}:", bg="white", font=('Segoe UI', 12, 'bold')).pack(anchor='w', pady=5)

        for item in self.file_list:
            icon = "📁" if "." not in item else "📄"
            tk.Label(content_frame, text=f"{icon} {item}", bg="white", font=('Segoe UI', 11), anchor='w').pack(fill='x')

    def show_notification(self, message):
         messagebox.showinfo("File Explorer Action", message)

# --- 3. ГЛАВНЫЙ GUI КЛАСС (PyOSGUI) ---

class PyOSGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("PythonOS 2.0 - PyGUI")
        
        self.root.state('zoomed') 
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        self.return_action = None
        self.start_menu_visible = False

        self.setup_styles()
        self.setup_ui()
        self.setup_start_menu()

    def setup_styles(self):
        self.desktop_bg = "#2f2f2f"  
        self.taskbar_bg = "#212121"  
        self.accent_color = "#0078D4" 
        self.text_color = "#ffffff"
        self.menu_bg = "#3c3c3c"
        
        self.root.config(bg=self.desktop_bg)

    def setup_ui(self):
        self.desktop_frame = tk.Frame(self.root, bg=self.desktop_bg)
        self.desktop_frame.pack(fill=tk.BOTH, expand=True)

        self.taskbar = tk.Frame(self.root, bg=self.taskbar_bg, height=35)
        self.taskbar.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.start_button = tk.Button(self.taskbar, text="★ Start", bg=self.accent_color, fg=self.text_color, 
                                 font=('Segoe UI', 10, 'bold'), bd=0, padx=10, 
                                 command=self.toggle_start_menu)
        self.start_button.pack(side=tk.LEFT, padx=5, pady=2)
        
        self.time_label = tk.Label(self.taskbar, text="", bg=self.taskbar_bg, fg=self.text_color, 
                                    font=('Segoe UI', 10))
        self.time_label.pack(side=tk.RIGHT, padx=10)
        self.update_time() 

        icon_frame = tk.Frame(self.desktop_frame, bg=self.desktop_bg)
        icon_frame.pack(side=tk.LEFT, anchor='nw', padx=10, pady=10)

        self.add_icon(icon_frame, "Terminal", "", self.launch_terminal)
        self.add_icon(icon_frame, "Explorer", "📁", self.launch_explorer)

    def launch_terminal(self):
        GUITerminal(self.root) 
    
    def launch_explorer(self):
        FileExplorer(self.root)

    # --- МЕТОДЫ ДЛЯ МЕНЮ ПУСК ---

    def setup_start_menu(self):
        self.start_menu_frame = tk.Frame(self.root, bg=self.menu_bg, width=250, height=350, bd=1, relief="solid")
        
        reboot_btn = tk.Button(self.start_menu_frame, text="↻ Reboot to BIOS", fg=self.text_color, bg=self.menu_bg, 
                               font=('Segoe UI', 10), bd=0, anchor='w', padx=10,
                               command=lambda: self.on_closing(action="reboot"))
        reboot_btn.pack(fill='x', pady=(5,0))
        reboot_btn.bind("<Enter>", lambda e: reboot_btn.config(bg="#555555"))
        reboot_btn.bind("<Leave>", lambda e: reboot_btn.config(bg=self.menu_bg))

        shutdown_btn = tk.Button(self.start_menu_frame, text="⏻ Shut Down", fg=self.text_color, bg=self.menu_bg, 
                                 font=('Segoe UI', 10), bd=0, anchor='w', padx=10,
                                 command=lambda: self.on_closing(action="shutdown"))
        shutdown_btn.pack(fill='x', pady=5)
        shutdown_btn.bind("<Enter>", lambda e: shutdown_btn.config(bg="#555555"))
        shutdown_btn.bind("<Leave>", lambda e: shutdown_btn.config(bg=self.menu_bg))

        self.start_menu_frame.place_forget() 

    def toggle_start_menu(self):
        if self.start_menu_visible:
            self.start_menu_frame.place_forget()
            self.start_menu_visible = False
        else:
            self.start_menu_frame.place(x=0, rely=1, anchor='sw') 
            self.start_menu_visible = True
            self.root.bind("<Button-1>", self.hide_start_menu_on_click)

    def hide_start_menu_on_click(self, event):
        if self.start_button.winfo_containing(event.x_root, event.y_root) != self.start_button:
            if self.start_menu_frame.winfo_containing(event.x_root, event.y_root) != self.start_menu_frame:
                self.toggle_start_menu()
                self.root.unbind("<Button-1>") 

    # --- ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ---
    
    def add_icon(self, parent_frame, text, symbol, command):
        icon_widget = tk.Frame(parent_frame, bg=self.desktop_bg, padx=10, pady=10, 
                               cursor="hand2", borderwidth=1, relief="flat")
        
        symbol_label = tk.Label(icon_widget, text=symbol, font=('Arial', 30), 
                                bg=self.desktop_bg, fg=self.text_color)
        symbol_label.pack(pady=2)

        text_label = tk.Label(icon_widget, text=text, font=('Segoe UI', 9), 
                              bg=self.desktop_bg, fg=self.text_color)
        text_label.pack()

        icon_widget.bind("<Button-1>", lambda event: command())
        symbol_label.bind("<Button-1>", lambda event: command())
        text_label.bind("<Button-1>", lambda event: command())

        icon_widget.bind("<Enter>", lambda event: self.on_hover(icon_widget, text_label, symbol_label, True))
        icon_widget.bind("<Leave>", lambda event: self.on_hover(icon_widget, text_label, symbol_label, False))

        icon_widget.pack(pady=5, anchor='w')
        return icon_widget

    def on_hover(self, widget, text_label, symbol_label, is_hover):
        if is_hover:
            widget.config(relief="solid", borderwidth=1, bg="#4a4a4a")
            text_label.config(bg="#4a4a4a")
            symbol_label.config(bg="#4a4a4a")
        else:
            widget.config(relief="flat", borderwidth=1, bg=self.desktop_bg)
            text_label.config(bg=self.desktop_bg)
            symbol_label.config(bg=self.desktop_bg)

    def update_time(self):
        current_time = time.strftime("%H:%M:%S\n%a %d %b")
        self.time_label.config(text=current_time)
        self.root.after(1000, self.update_time)

    def show_notification(self, title, message):
        messagebox.showinfo(title, message)

    def on_closing(self, action=None):
        # Если команда пришла из меню Пуск
        if action == "shutdown":
            self.return_action = "halt"
            self.root.quit()
        elif action == "reboot":
            self.return_action = "bootmenu"
            self.root.quit()
        
        # Если пользователь нажимает крестик окна, спрашиваем
        else:
            response = messagebox.askquestion("Shutdown / Reboot", 
                                          "Вы хотите полностью выключить систему (Shut Down) или перезагрузить в BIOS (Reboot)?",
                                          icon='warning', 
                                          type='yesnocancel', 
                                          default='no')

            if response == 'yes': 
                self.return_action = "halt"
                self.root.quit()
            elif response == 'no': 
                self.return_action = "bootmenu"
                self.root.quit()

def run_pyos_gui():
    gui = PyOSGUI()
    # Запускаем основной цикл Tkinter.
    gui.root.mainloop() 
    
    # ⭐ ГАРАНТИЯ ЗАКРЫТИЯ: Уничтожаем корневое окно Tkinter после завершения mainloop.
    try:
        gui.root.destroy()
    except tk.TclError:
        pass
    
    return gui.return_action if gui.return_action else "halt"