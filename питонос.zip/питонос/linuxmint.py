# linuxmint.py (PyQt-реализация Linux Mint GUI - ДЕМОНСТРАЦИОННАЯ)

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFrame, QMessageBox
)
from PyQt6.QtCore import Qt, QTimer, QDateTime
from PyQt6.QtGui import QFont, QIcon # Импортируем QIcon
import sys
import os
import time

# Используем 'Ubuntu' или 'DejaVu Sans' как типичные шрифты Linux
FONT = "DejaVu Sans"

# Специальный класс для нажимаемых иконок (оставляем, но привязываем к сообщению)
class ClickableIcon(QWidget):
    def __init__(self, text, symbol, parent=None):
        super().__init__(parent)
        self.setFixedSize(80, 80)
        
        icon_layout = QVBoxLayout(self)
        icon_layout.setContentsMargins(0, 0, 0, 0)
        
        self.symbol_label = QLabel(symbol)
        self.symbol_label.setFont(QFont(FONT, 28))
        self.symbol_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.symbol_label.setObjectName("IconSymbol")

        self.text_label = QLabel(text)
        self.text_label.setFont(QFont(FONT, 9))
        self.text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.text_label.setObjectName("IconText")
        
        icon_layout.addWidget(self.symbol_label)
        icon_layout.addWidget(self.text_label)

    # Иконки не будут делать ничего, кроме вызова сообщения
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            QMessageBox.information(self.parent().parent(), "Ошибка", 
                                     f"Приложение '{self.text_label.text()}' не может быть запущено в симуляции.")

class LinuxMintGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Linux Mint (Cinnamon Simulation) - DEMO")
        
        self.setWindowState(Qt.WindowState.WindowMaximized) 
        self.setMinimumSize(800, 600)
        self.return_action = None

        self.setup_ui()
        self.apply_styles()
        self.update_time()

        self.closeEvent = self.on_closing

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        desktop_widget = QWidget()
        desktop_widget.setObjectName("Desktop")
        desktop_layout = QHBoxLayout(desktop_widget)
        desktop_layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        desktop_layout.setContentsMargins(20, 20, 20, 20)

        icon_column = QVBoxLayout()
        icon_column.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        # Иконки - теперь просто ClickableIcon
        icon_column.addWidget(ClickableIcon("Home Folder", "📁", self))
        icon_column.addWidget(ClickableIcon("Terminal", "", self))
        icon_column.addWidget(ClickableIcon("Firefox", "", self))
        
        desktop_layout.addLayout(icon_column)
        desktop_layout.addStretch(1)

        control_widget = QWidget()
        control_layout = QVBoxLayout(control_widget)
        control_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        title_label = QLabel("Linux Mint - DEMO MODE")
        title_label.setFont(QFont(FONT, 24, QFont.Weight.Bold))
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setObjectName("TitleLabel")
        
        info_label = QLabel("Эта ОС неинтерактивна и предназначена только для демонстрации GUI.\nНажмите 'Reboot' для возврата в BIOS.")
        info_label.setFont(QFont(FONT, 12))
        info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        boot_menu_button = QPushButton("Reboot to BIOS")
        boot_menu_button.setFont(QFont(FONT, 14, QFont.Weight.Bold))
        boot_menu_button.setFixedSize(250, 50)
        boot_menu_button.clicked.connect(self.return_to_boot_menu)
        boot_menu_button.setObjectName("RebootButton")
        
        control_layout.addWidget(title_label)
        control_layout.addWidget(info_label)
        control_layout.addWidget(boot_menu_button, alignment=Qt.AlignmentFlag.AlignCenter)
        
        desktop_layout.addWidget(control_widget, alignment=Qt.AlignmentFlag.AlignCenter)
        
        main_layout.addWidget(desktop_widget)
        
        # Панель задач
        self.taskbar = QFrame()
        self.taskbar.setObjectName("Taskbar")
        self.taskbar.setFixedHeight(30)
        
        taskbar_layout = QHBoxLayout(self.taskbar)
        taskbar_layout.setContentsMargins(5, 0, 5, 0)
        taskbar_layout.setSpacing(10)
        
        menu_button = QPushButton("★ Menu")
        menu_button.setObjectName("MenuButton")
        menu_button.setFont(QFont(FONT, 10, QFont.Weight.Bold))
        menu_button.setFixedSize(80, 24)
        menu_button.clicked.connect(lambda: QMessageBox.information(self, "Menu", "Меню не функционально."))
        taskbar_layout.addWidget(menu_button)
        
        taskbar_layout.addStretch(1)
        
        self.time_label = QLabel()
        self.time_label.setFont(QFont(FONT, 10))
        taskbar_layout.addWidget(self.time_label)
        
        main_layout.addWidget(self.taskbar)
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)

    # ... (apply_styles, update_time - без изменений)
    def apply_styles(self):
        style_sheet = """
        QMainWindow {
            background-color: #353b3c;
        }
        #Taskbar {
            background-color: #2c3132;
            border-top: 1px solid #4a4a4a;
        }
        #Desktop QLabel {
            color: #d3d7cf;
        }
        #TitleLabel {
            color: #73d216;
            padding: 10px;
        }
        #MenuButton {
            background-color: #73d216; 
            color: #000000;
            border-radius: 4px;
            padding: 3px;
            border: none;
        }
        #MenuButton:hover {
            background-color: #92e035;
        }
        #RebootButton {
            background-color: #cc0000; 
            color: #ffffff;
            border-radius: 8px;
            padding: 10px;
            border: none;
        }
        #RebootButton:hover {
            background-color: #ff0000;
        }
        ClickableIcon:hover {
            background-color: #4a4a4a; /* Эффект при наведении */
            border: 1px solid #73d216;
        }
        ClickableIcon QLabel {
            background: transparent;
        }
        """
        self.setStyleSheet(style_sheet)
    
    def update_time(self):
        current_time = QDateTime.currentDateTime().toString("HH:mm:ss  ddd dd MMM")
        self.time_label.setText(current_time)

    def return_to_boot_menu(self):
        """Функция, вызываемая при нажатии кнопки 'Reboot to BIOS'."""
        self.return_action = "bootmenu" 
        self.close()

    def on_closing(self, event):
        """Функция, вызываемая при закрытии окна (нажатии на 'X')."""
        reply = QMessageBox.question(self, 'Shutdown', 
                                     "Вы уверены, что хотите завершить работу системы? (Да = Выключить, Нет = Перезагрузка в BIOS)", 
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, 
                                     QMessageBox.StandardButton.No)

        if reply == QMessageBox.StandardButton.Yes:
            self.return_action = "halt"
            event.accept()
        else:
            self.return_action = "bootmenu" 
            event.accept()

def run_linux_mint_gui():
    """Точка входа для запуска GUI из main.py."""
    app = QApplication.instance()
    if not app:
        app = QApplication(sys.argv)
        # Установка заглушки для иконки, чтобы избежать предупреждений PyQt
        app.setWindowIcon(QIcon()) 
            
    window = LinuxMintGUI()
    window.show() 
    app.exec()
    
    return window.return_action if window.return_action else "halt"