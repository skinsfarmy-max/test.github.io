# bios.py (ОБНОВЛЕННЫЙ КОД для трех ОС)
import os
import time
import sys

# Попытка импортировать msvcrt только на Windows
try:
    if os.name == 'nt':
        import msvcrt
except ImportError:
    pass

class BIOS:
    def __init__(self):
        # ИЗМЕНЕНИЕ: Добавляем PyOS 2.0 и Linux Mint
        self.boot_options = ["HDD: PythonOS (CLI)", "HDD: Linux Mint (Demo)", "HDD: PythonOS 2.0 (PyGUI)", "USB: Recovery", "CD-ROM: Install Disk", "Network Boot"] 
        self.selected_option = 0
        self.current_menu = "main"
        self.menu_map = {
            1: "advanced",
            2: "peripherals",
            3: "power",
            4: "pnp",
            5: "health",
        }

    # ... (методы clear_screen, get_key, display_bios_screen, display_boot_menu и другие меню - без изменений)

    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def get_key(self):
        """Простой ввод с поддержкой стрелочек через WASD"""
        try:
            if os.name == 'nt':  # Windows
                import msvcrt
                key = msvcrt.getch()
                if key == b'\xe0':  # Специальные клавиши
                    key = msvcrt.getch()
                    if key == b'H': return 'up'
                    elif key == b'P': return 'down'
                    elif key == b'M': return 'right'
                    elif key == b'K': return 'left'
                elif key == b'\r': return 'enter'
                elif key == b'\x1b': return 'esc'
                elif key == b'\x00': 
                    key = msvcrt.getch()
                    if key == b';': return 'f10'
                else: 
                    return key.decode('utf-8').lower()
            else:  # Linux/Mac
                import termios
                import tty
                fd = sys.stdin.fileno()
                old_settings = termios.tcgetattr(fd)
                try:
                    tty.setraw(fd)
                    ch = sys.stdin.read(1)
                    if ch == '\x1b':  # Escape sequence
                        ch = sys.stdin.read(2)
                        if ch == '[A': return 'up'
                        elif ch == '[B': return 'down'
                        elif ch == '[C': return 'd'
                        elif ch == '[D': return 'a'
                    elif ch == '\r' or ch == '\n': return 'enter'
                    elif ch == '\x1b': return 'esc'
                    else: return ch.lower()
                finally:
                    termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        except Exception:
            key = input(">> ").lower()
            if key == 'w': return 'up'
            elif key == 's': return 'down'
            elif key == 'a': return 'left'
            elif key == 'd': return 'right'
            elif key == '': return 'enter'
            elif key == 'f10': return 'f10'
            elif key == 'esc': return 'esc'
            else: return key
        return None

    def display_bios_screen(self):
        self.clear_screen()
        print("=" * 60)
        print("            AWARD BIOS SETUP UTILITY")
        print("=" * 60)
        print()
        
        menus = [
            "Standard CMOS Features",
            "Advanced BIOS Features", 
            "Integrated Peripherals",
            "Power Management Setup",
            "PnP/PCI Configurations",
            "PC Health Status",
            "Load Fail-Safe Defaults",
            "Load Optimized Defaults",
            "Set Password",
            "Save & Exit Setup",
            "Exit Without Saving"
        ]
        
        for i, menu in enumerate(menus):
            prefix = ">>> " if i == self.selected_option else "    "
            print(f"{prefix}{menu}")
        
        print()
        print("Use ↑↓ to select, Enter to confirm, F10 to Save & Exit")

    def display_boot_menu(self):
        self.clear_screen()
        print("=" * 60)
        print("                BOOT DEVICE SELECTION")
        print("=" * 60)
        print()
        
        for i, option in enumerate(self.boot_options):
            prefix = ">>> " if i == self.selected_option else "    "
            print(f"{prefix}{option}")
        
        print()
        print("Press Enter to boot from selected device")
        print("Press ESC to return to BIOS")
    
    # ... (Остальные display_*_menu, show_*_info - без изменений)

    def display_advanced_menu(self):
        self.clear_screen()
        print("=" * 60)
        print("              ADVANCED BIOS FEATURES")
        print("=" * 60)
        print()
        
        options = [
            "Quick Boot: Enabled",
            "Boot Device Priority", 
            "Boot Up Floppy Seek: Disabled",
            "Password Check: Setup",
            "APIC Mode: Enabled",
            "MPS Version: 1.4",
            "OS Select For DRAM > 64MB: Non-OS2",
            "HDD S.M.A.R.T. Capability: Enabled"
        ]
        
        for i, option in enumerate(options):
            prefix = ">>> " if i == self.selected_option else "    "
            print(f"{prefix}{option}")
        
        print()
        print("Press Enter to select, ESC to return")

    def display_peripherals_menu(self):
        self.clear_screen()
        print("=" * 60)
        print("              INTEGRATED PERIPHERALS")
        print("=" * 60)
        print()
        
        options = [
            "OnChip IDE Channel0: Enabled",
            "OnChip IDE Channel1: Enabled", 
            "USB Controller: Enabled",
            "USB Keyboard Support: Enabled",
            "AC97 Audio: Auto",
            "AC97 Modem: Auto",
            "Onboard LAN: Enabled"
        ]
        
        for i, option in enumerate(options):
            prefix = ">>> " if i == self.selected_option else "    "
            print(f"{prefix}{option}")
        
        print()
        print("Press ESC to return")

    def display_power_menu(self):
        self.clear_screen()
        print("=" * 60)
        print("              POWER MANAGEMENT SETUP")
        print("=" * 60)
        print()
        
        options = [
            "ACPI Suspend Type: S3 (STR)",
            "Power Management: Enabled",
            "Video Off Method: DPMS", 
            "HDD Power Down: After 15 Min",
            "Soft-Off by PWR-BTTN: Instant-Off"
        ]
        
        for i, option in enumerate(options):
            prefix = ">>> " if i == self.selected_option else "    "
            print(f"{prefix}{option}")
        
        print()
        print("Press ESC to return")

    def display_pnp_menu(self):
        self.clear_screen()
        print("=" * 60)
        print("              PnP/PCI CONFIGURATIONS")
        print("=" * 60)
        print()
        
        options = [
            "PNP OS Installed: Yes",
            "Reset Configuration Data: Disabled",
            "Resources Controlled By: Auto", 
            "IRQ Resources: Press Enter",
            "DMA Resources: Press Enter"
        ]
        
        for i, option in enumerate(options):
            prefix = ">>> " if i == self.selected_option else "    "
            print(f"{prefix}{option}")
        
        print()
        print("Press ESC to return")

    def display_health_menu(self):
        self.clear_screen()
        print("=" * 60)
        print("                PC HEALTH STATUS")
        print("=" * 60)
        print()
        
        options = [
            "CPU Temperature: 45°C",
            "CPU Fan Speed: 2550 RPM", 
            "System Temperature: 35°C",
            "CPU Voltage: 1.35V",
            "+3.3V Voltage: 3.28V",
            "+5V Voltage: 5.05V",
            "+12V Voltage: 12.10V"
        ]
        
        for i, option in enumerate(options):
            prefix = ">>> " if i == self.selected_option else "    "
            print(f"{prefix}{option}")
        
        print()
        print("Press ESC to return")

    def show_cmos_info(self):
        self.clear_screen()
        print("=" * 60)
        print("                STANDARD CMOS FEATURES")
        print("=" * 60)
        print()
        print("Date (mm/dd/yy): 01/01/2025")
        print("Time (hh/mm/ss): 12:00:00")
        print()
        print("Primary Master: PythonOS HDD 1.0GB")
        print("Primary Slave: None")
        print("Secondary Master: CD-ROM Drive")
        print("Secondary Slave: None")
        print()
        print("Base Memory: 640K")
        print("Extended Memory: 15872K")
        print()
        input("Press Enter to continue...")

    def show_fail_safe_defaults(self):
        self.clear_screen()
        print("=" * 60)
        print("            LOAD FAIL-SAFE DEFAULTS")
        print("=" * 60)
        print("\nLoad fail-safe defaults? (Y/N)")
        print("\nSettings restored to fail-safe defaults!")
        input("Press Enter to continue...")

    def show_optimized_defaults(self):
        self.clear_screen()
        print("=" * 60)
        print("            LOAD OPTIMIZED DEFAULTS")
        print("=" * 60)
        print("\nLoad optimized defaults? (Y/N)")
        print("\nSettings restored to optimized defaults!")
        input("Press Enter to continue...")

    def show_password_menu(self):
        self.clear_screen()
        print("=" * 60)
        print("                   SET PASSWORD")
        print("=" * 60)
        print("\nEnter new password: ****")
        print("\nConfirm password: ****")
        print("\nPassword set successfully!")
        input("Press Enter to continue...")


    def run(self):
        print("Initializing BIOS...")
        time.sleep(1)
        print("Detecting IDE Drives...")
        time.sleep(0.5)
        print("Primary Master: PythonOS HDD 1.0GB")
        time.sleep(0.5)
        print("Memory Test: 16384KB OK")
        time.sleep(1)
        
        input("Press Enter to enter BIOS setup...")
        
        while True:
            if self.current_menu == "main":
                self.display_bios_screen()
                key = self.get_key()
                
                if key == 'up':
                    self.selected_option = (self.selected_option - 1) % 11
                elif key == 'down':
                    self.selected_option = (self.selected_option + 1) % 11
                elif key == 'enter':
                    if self.selected_option == 0:  # Standard CMOS Features
                        self.show_cmos_info()
                    elif self.selected_option in [1, 2, 3, 4, 5]: # Other menus
                        self.current_menu = self.menu_map.get(self.selected_option, "main")
                        self.selected_option = 0
                    elif self.selected_option == 6:  # Load Fail-Safe Defaults
                        self.show_fail_safe_defaults()
                    elif self.selected_option == 7:  # Load Optimized Defaults
                        self.show_optimized_defaults()
                    elif self.selected_option == 8:  # Set Password
                        self.show_password_menu()
                    elif self.selected_option == 9:  # Save & Exit Setup
                        print("Saving BIOS settings...")
                        time.sleep(1)
                        return "pyos_gui" 
                    elif self.selected_option == 10:  # Exit Without Saving
                        return "pyos_gui"
                elif key == 'f10':
                    return "pyos_gui"
                    
            elif self.current_menu == "advanced":
                self.display_advanced_menu()
                key = self.get_key()
                
                if key == 'up':
                    self.selected_option = (self.selected_option - 1) % 8
                elif key == 'down':
                    self.selected_option = (self.selected_option + 1) % 8
                elif key == 'enter':
                    if self.selected_option == 1:  # Boot Device Priority
                        self.current_menu = "boot" 
                        self.selected_option = 0
                elif key == 'esc':
                    self.current_menu = "main"
                    self.selected_option = 1
                    
            elif self.current_menu == "peripherals":
                self.display_peripherals_menu()
                key = self.get_key()
                
                if key == 'up':
                    self.selected_option = (self.selected_option - 1) % 7
                elif key == 'down':
                    self.selected_option = (self.selected_option + 1) % 7
                elif key == 'esc':
                    self.current_menu = "main"
                    self.selected_option = 2
                    
            elif self.current_menu == "power":
                self.display_power_menu()
                key = self.get_key()
                
                if key == 'up':
                    self.selected_option = (self.selected_option - 1) % 5
                elif key == 'down':
                    self.selected_option = (self.selected_option + 1) % 5
                elif key == 'esc':
                    self.current_menu = "main"
                    self.selected_option = 3
                    
            elif self.current_menu == "pnp":
                self.display_pnp_menu()
                key = self.get_key()
                
                if key == 'up':
                    self.selected_option = (self.selected_option - 1) % 5
                elif key == 'down':
                    self.selected_option = (self.selected_option + 1) % 5
                elif key == 'esc':
                    self.current_menu = "main"
                    self.selected_option = 4
                    
            elif self.current_menu == "health":
                self.display_health_menu()
                key = self.get_key()
                
                if key == 'up':
                    self.selected_option = (self.selected_option - 1) % 7
                elif key == 'down':
                    self.selected_option = (self.selected_option + 1) % 7
                elif key == 'esc':
                    self.current_menu = "main"
                    self.selected_option = 5
                    
            elif self.current_menu == "boot":
                self.display_boot_menu()
                key = self.get_key()
                
                if key == 'up':
                    self.selected_option = (self.selected_option - 1) % len(self.boot_options)
                elif key == 'down':
                    self.selected_option = (self.selected_option + 1) % len(self.boot_options)
                elif key == 'enter':
                    if self.selected_option == 0:  # PythonOS (CLI)
                        return "pythonos"
                    elif self.selected_option == 1: # Linux Mint (Demo)
                        return "linuxmint"
                    elif self.selected_option == 2: # PythonOS 2.0 (GUI)
                        return "pyos_gui"
                    else:
                        print(f"Booting from {self.boot_options[self.selected_option]}...")
                        time.sleep(2)
                        print("Boot failed: No operating system found")
                        time.sleep(1)
                elif key == 'esc':
                    self.current_menu = "advanced"
                    self.selected_option = 1