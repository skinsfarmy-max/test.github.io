# main.py (ФИНАЛЬНАЯ ВЕРСИЯ С 3-МЯ ОС И БЛОКИРОВКОЙ)

from bios import BIOS
from pythonos import PythonOS
from linuxmint import run_linux_mint_gui 
from pyos_gui import run_pyos_gui 
import os
import time

def main():
    # Инициализируем PythonOS один раз
    python_os = PythonOS()
    next_action = "boot" 

    # --- Главный цикл загрузки ---
    while next_action != "halt":
        
        # Очистка консоли перед новым циклом
        if next_action not in ["pyos_gui", "linuxmint"]:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("Starting Virtual Machine...")
            time.sleep(0.5)
        
        if next_action == "boot" or next_action == "bootmenu":
            # 1. Запуск BIOS/Boot Menu
            print("--- Entering BIOS/Boot Menu ---")
            bios = BIOS()
            next_action = bios.run() 
        
        if next_action == "pythonos":
            # 2. Запуск PythonOS (Терминал CLI)
            print("--- Booting PythonOS (CLI Terminal) ---")
            time.sleep(1) 
            next_action = python_os.run() 
        
        elif next_action == "linuxmint":
            # 3. Запуск Linux Mint GUI (PyQt - демонстрация)
            print("--- Booting Linux Mint (GUI Demo) ---")
            time.sleep(1) 
            next_action = run_linux_mint_gui() 
            
        elif next_action == "pyos_gui":
            # 4. Запуск PythonOS 2.0 GUI (Tkinter - интерактивная)
            print("--- Booting PythonOS 2.0 (PyGUI Interactive) ---")
            time.sleep(1) 
            next_action = run_pyos_gui() 
        
        elif next_action == "boot":
            next_action = "bootmenu"

    # Выход из цикла (next_action == "halt")
    os.system('cls' if os.name == 'nt' else 'clear')
    print("\nSystem halted. Goodbye!")
    
    # ⭐ ГАРАНТИЯ ОТ ЗАКРЫТИЯ: ждем Enter
    try:
        input("Press Enter to close the terminal...") 
    except EOFError:
        pass

if __name__ == "__main__":
    main()