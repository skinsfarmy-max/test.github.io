# -*- coding: utf-8 -*-
"""
Модуль диспетчера задач Т-ОС
Мониторинг процессов и системных ресурсов
"""

import tkinter as tk
from tkinter import ttk
import threading
import time
import psutil

class TaskManager:
    """Класс диспетчера задач"""
    
    def __init__(self, root, os_system):
        self.root = root
        self.os_system = os_system
        
        # Создание окна диспетчера задач
        self.window = tk.Toplevel(root)
        self.window.title("Диспетчер задач - Т-ОС")
        self.window.geometry("700x500")
        
        # Создание вкладок
        self.create_tabs()
        
        # Запуск обновления информации
        self.update_interval = 2000  # 2 секунды
        self.update_info()
        
        # Регистрация в системе
        self.os_system.register_window(self.window)
        self.window.protocol("WM_DELETE_WINDOW", self.on_close)
    
    def create_tabs(self):
        """Создание вкладок диспетчера задач"""
        notebook = ttk.Notebook(self.window)
        notebook.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Вкладка "Процессы"
        processes_frame = ttk.Frame(notebook)
        notebook.add(processes_frame, text="Процессы")
        self.create_processes_tab(processes_frame)
        
        # Вкладка "Производительность"
        performance_frame = ttk.Frame(notebook)
        notebook.add(performance_frame, text="Производительность")
        self.create_performance_tab(performance_frame)
    
    def create_processes_tab(self, parent):
        """Создание вкладки процессов"""
        # Панель инструментов
        toolbar = tk.Frame(parent, height=30)
        toolbar.pack(fill='x')
        toolbar.pack_propagate(False)
        
        end_task_btn = tk.Button(toolbar, text="Снять задачу", 
                               command=self.end_selected_task)
        end_task_btn.pack(side='left', padx=5, pady=2)
        
        # Таблица процессов
        columns = ("name", "pid", "status", "cpu", "memory")
        self.process_tree = ttk.Treeview(parent, columns=columns, show='headings')
        
        self.process_tree.heading("name", text="Имя процесса")
        self.process_tree.heading("pid", text="PID")
        self.process_tree.heading("status", text="Статус")
        self.process_tree.heading("cpu", text="ЦПУ %")
        self.process_tree.heading("memory", text="Память")
        
        self.process_tree.column("name", width=200)
        self.process_tree.column("pid", width=80)
        self.process_tree.column("status", width=100)
        self.process_tree.column("cpu", width=80)
        self.process_tree.column("memory", width=100)
        
        scrollbar = ttk.Scrollbar(parent, orient='vertical', 
                                command=self.process_tree.yview)
        self.process_tree.configure(yscrollcommand=scrollbar.set)
        
        self.process_tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
    
    def create_performance_tab(self, parent):
        """Создание вкладки производительности"""
        # Информация о ЦПУ
        cpu_frame = tk.LabelFrame(parent, text="Процессор (ЦПУ)", padx=10, pady=10)
        cpu_frame.pack(fill='x', padx=10, pady=5)
        
        self.cpu_label = tk.Label(cpu_frame, text="Загрузка: 0%", font=('Arial', 12))
        self.cpu_label.pack(anchor='w')
        
        self.cpu_bar = ttk.Progressbar(cpu_frame, orient='horizontal', length=200, mode='determinate')
        self.cpu_bar.pack(fill='x', pady=5)
        
        # Информация о памяти
        memory_frame = tk.LabelFrame(parent, text="Память", padx=10, pady=10)
        memory_frame.pack(fill='x', padx=10, pady=5)
        
        self.memory_label = tk.Label(memory_frame, text="Использовано: 0 MB / 0 MB (0%)", 
                                   font=('Arial', 12))
        self.memory_label.pack(anchor='w')
        
        self.memory_bar = ttk.Progressbar(memory_frame, orient='horizontal', 
                                        length=200, mode='determinate')
        self.memory_bar.pack(fill='x', pady=5)
        
        # Информация о системе
        system_frame = tk.LabelFrame(parent, text="Система", padx=10, pady=10)
        system_frame.pack(fill='x', padx=10, pady=5)
        
        self.system_info = tk.Text(system_frame, height=8, width=60)
        self.system_info.pack(fill='both', expand=True)
    
    def update_info(self):
        """Обновление информации в диспетчере задач"""
        try:
            # Обновление процессов
            self.update_processes()
            
            # Обновление производительности
            self.update_performance()
            
            # Обновление системной информации
            self.update_system_info()
            
        except Exception as e:
            print(f"Ошибка обновления диспетчера задач: {e}")
        
        # Планирование следующего обновления
        self.window.after(self.update_interval, self.update_info)
    
    def update_processes(self):
        """Обновление списка процессов"""
        # Очистка текущего списка
        for item in self.process_tree.get_children():
            self.process_tree.delete(item)
        
        # Добавление системных процессов
        system_processes = [
            ("Т-ОС Система", "0", "Выполняется", "1%", "50 MB"),
            ("Проводник", "1", "Выполняется", "2%", "25 MB"),
            ("Диспетчер задач", "2", "Выполняется", "1%", "15 MB"),
        ]
        
        for process in system_processes:
            self.process_tree.insert("", "end", values=process)
        
        # Добавление пользовательских процессов (окон)
        for i, window in enumerate(self.os_system.open_windows, 3):
            try:
                title = window.title() if hasattr(window, 'title') else f"Окно {i}"
                self.process_tree.insert("", "end", 
                                       values=(title, str(i), "Выполняется", "0%", "10 MB"))
            except:
                pass
    
    def update_performance(self):
        """Обновление информации о производительности"""
        try:
            # Информация о ЦПУ
            cpu_percent = psutil.cpu_percent(interval=None)
            self.cpu_label.config(text=f"Загрузка: {cpu_percent:.1f}%")
            self.cpu_bar['value'] = cpu_percent
            
            # Информация о памяти
            memory = psutil.virtual_memory()
            used_gb = memory.used / (1024**3)
            total_gb = memory.total / (1024**3)
            percent = memory.percent
            
            self.memory_label.config(
                text=f"Использовано: {used_gb:.1f} GB / {total_gb:.1f} GB ({percent:.1f}%)"
            )
            self.memory_bar['value'] = percent
            
        except Exception as e:
            # Заглушка если psutil не доступен
            self.cpu_label.config(text="Загрузка: Н/Д")
            self.memory_label.config(text="Использовано: Н/Д")
    
    def update_system_info(self):
        """Обновление системной информации"""
        try:
            info_text = f"""Т-ОС Версия 1.0
Процессор: {psutil.cpu_count()} ядер
Оперативная память: {psutil.virtual_memory().total // (1024**3)} GB
Система: Python {sys.version.split()[0]}
Пользователь: {self.os_system.current_user}

Запущено процессов: {len(self.os_system.open_windows) + 3}
Время работы: {time.strftime('%H:%M:%S')}"""
            
            self.system_info.delete(1.0, tk.END)
            self.system_info.insert(1.0, info_text)
            
        except:
            info_text = """Т-ОС Версия 1.0
Система: Python
Пользователь: Пользователь

Информация о системе недоступна"""
            self.system_info.delete(1.0, tk.END)
            self.system_info.insert(1.0, info_text)
    
    def end_selected_task(self):
        """Завершение выбранной задачи"""
        selection = self.process_tree.selection()
        if selection:
            item = selection[0]
            values = self.process_tree.item(item, 'values')
            process_name = values[0]
            
            # Поиск и закрытие соответствующего окна
            for window in self.os_system.open_windows[:]:
                try:
                    if (hasattr(window, 'title') and 
                        window.title() == process_name):
                        window.destroy()
                        self.os_system.unregister_window(window)
                        break
                except:
                    pass
            
            # Обновление списка процессов
            self.update_processes()
    
    def on_close(self):
        """Обработка закрытия окна"""
        self.os_system.unregister_window(self.window)
        self.window.destroy()
    
    def lift(self):
        """Поднять окно на передний план"""
        self.window.lift()