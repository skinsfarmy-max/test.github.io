# -*- coding: utf-8 -*-
"""
Модуль панели задач Т-ОС
Функциональная панель задач с работающими кнопками окон
"""

import tkinter as tk
from tkinter import ttk
import time

class Taskbar:
    """Класс панели задач Т-ОС"""
    
    def __init__(self, root, os_system):
        self.root = root
        self.os_system = os_system
        self.task_buttons = []
        
        # Создание фрейма панели задач Т-ОС
        self.frame = tk.Frame(root, bg='#2d2d2d', height=40, relief='raised', bd=1)
        self.frame.pack(side='bottom', fill='x')
        self.frame.pack_propagate(False)
        
        # Левая часть: кнопка Пуск
        self.create_start_button()
        
        # Центральная часть: кнопки открытых окон
        self.tasks_frame = tk.Frame(self.frame, bg='#2d2d2d')
        self.tasks_frame.pack(side='left', fill='both', expand=True, padx=5)
        
        # Правая часть: системный трей
        self.create_system_tray()
        
        # Обновление панели задач
        self.update_taskbar()
        self.update_time()
    
    def create_start_button(self):
        """Создание кнопки Пуск Т-ОС"""
        start_frame = tk.Frame(self.frame, bg='#2d2d2d', width=50)
        start_frame.pack(side='left', fill='y')
        start_frame.pack_propagate(False)
        
        self.start_button = tk.Button(start_frame, text="Т", font=('Arial', 14, 'bold'),
                                    bg='#0078d4', fg='white', bd=0, cursor="hand2",
                                    command=self.os_system.open_start_menu,
                                    width=3, height=1)
        self.start_button.pack(fill='both', expand=True, padx=2, pady=2)
        
        # Эффект при наведении
        self.start_button.bind("<Enter>", lambda e: self.start_button.config(bg='#106ebe'))
        self.start_button.bind("<Leave>", lambda e: self.start_button.config(bg='#0078d4'))
    
    def create_system_tray(self):
        """Создание системного трея Т-ОС"""
        tray_frame = tk.Frame(self.frame, bg='#2d2d2d', width=150)
        tray_frame.pack(side='right', fill='y')
        tray_frame.pack_propagate(False)
        
        # Часы и дата
        self.time_label = tk.Label(tray_frame, bg='#2d2d2d', fg='white', 
                                 font=('Arial', 10), cursor="hand2")
        self.time_label.pack(side='right', padx=5)
        
        # Клик по времени показывает дату
        self.time_label.bind("<Button-1>", self.show_date_dialog)
    
    def update_time(self):
        """Обновление времени в системном трее Т-ОС"""
        current_time = time.strftime("%H:%M")
        self.time_label.config(text=current_time)
        self.root.after(1000, self.update_time)
    
    def show_date_dialog(self, event=None):
        """Показать диалог с датой и временем"""
        from tkinter import messagebox
        full_date = time.strftime("%d.%m.%Y %H:%M:%S")
        messagebox.showinfo("Дата и время Т-ОС", f"Текущее время:\n{full_date}")
    
    def update_taskbar(self):
        """Обновление кнопок открытых окон Т-ОС"""
        # Очистка старых кнопок
        for widget in self.tasks_frame.winfo_children():
            widget.destroy()
        
        self.task_buttons = []
        
        # Создание кнопок для каждого открытого окна Т-ОС
        for i, window in enumerate(self.os_system.open_windows):
            try:
                if hasattr(window, 'title'):
                    title = window.title()
                else:
                    title = f"Окно {i+1}"
                
                # Убираем суффикс " - Т-ОС" для краткости
                if " - Т-ОС" in title:
                    title = title.replace(" - Т-ОС", "")
                
                btn = tk.Button(self.tasks_frame, text=title[:20], 
                              bg='#3c3c3c', fg='white', bd=0, cursor="hand2",
                              font=('Arial', 9),
                              command=lambda w=window: self.focus_window(w))
                btn.pack(side='left', padx=2, pady=2)
                
                # Выделение активного окна
                if window == self.os_system.active_window:
                    btn.config(bg='#0078d4')
                else:
                    btn.config(bg='#3c3c3c')
                
                # Эффекты наведения
                btn.bind("<Enter>", lambda e, b=btn: b.config(bg='#505050') if b.cget('bg') != '#0078d4' else None)
                btn.bind("<Leave>", lambda e, b=btn: b.config(bg='#3c3c3c') if b.cget('bg') != '#0078d4' else None)
                
                self.task_buttons.append(btn)
                
            except Exception as e:
                print(f"Ошибка создания кнопки задачи: {e}")
        
        # Если нет открытых окон, показываем только кнопку рабочего стола
        if not self.os_system.open_windows:
            desktop_btn = tk.Button(self.tasks_frame, text="Рабочий стол", 
                                  bg='#3c3c3c', fg='white', bd=0, cursor="hand2",
                                  command=self.show_desktop)
            desktop_btn.pack(side='left', padx=2, pady=2)
            self.task_buttons.append(desktop_btn)
    
    def focus_window(self, window):
        """Активация окна Т-ОС при клике на кнопке в панели задач"""
        self.os_system.focus_window(window)
        self.update_taskbar()
    
    def show_desktop(self):
        """Показать рабочий стол (свернуть все окна Т-ОС)"""
        for window in self.os_system.open_windows:
            try:
                if hasattr(window, 'withdraw'):
                    window.withdraw()  # Скрыть окно
                elif hasattr(window, 'iconify'):
                    window.iconify()   # Свернуть в иконку
            except:
                pass
        
        self.os_system.active_window = None
        self.update_taskbar()