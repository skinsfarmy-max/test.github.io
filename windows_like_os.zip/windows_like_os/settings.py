# -*- coding: utf-8 -*-
"""
Модуль настроек Т-ОС
Изменение параметров системы, тем и обоев
"""

import tkinter as tk
from tkinter import ttk, colorchooser, filedialog

class Settings:
    """Класс настроек системы"""
    
    def __init__(self, root, os_system):
        self.root = root
        self.os_system = os_system
        
        # Создание окна настроек
        self.window = tk.Toplevel(root)
        self.window.title("Настройки - Т-ОС")
        self.window.geometry("500x400")
        
        self.create_content()
        
        # Регистрация в системе
        self.os_system.register_window(self.window)
        self.window.protocol("WM_DELETE_WINDOW", self.on_close)
    
    def create_content(self):
        """Создание содержимого настроек"""
        notebook = ttk.Notebook(self.window)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Вкладка "Внешний вид"
        appearance_frame = ttk.Frame(notebook)
        notebook.add(appearance_frame, text="Внешний вид")
        self.create_appearance_tab(appearance_frame)
        
        # Вкладка "Система"
        system_frame = ttk.Frame(notebook)
        notebook.add(system_frame, text="Система")
        self.create_system_tab(system_frame)
        
        # Вкладка "Персонализация"
        personalization_frame = ttk.Frame(notebook)
        notebook.add(personalization_frame, text="Персонализация")
        self.create_personalization_tab(personalization_frame)
    
    def create_appearance_tab(self, parent):
        """Создание вкладки внешнего вида"""
        # Выбор темы
        theme_frame = tk.LabelFrame(parent, text="Тема оформления", padx=10, pady=10)
        theme_frame.pack(fill='x', padx=10, pady=5)
        
        themes = ["Светлая", "Темная", "Системная"]
        self.theme_var = tk.StringVar(value="Темная")
        
        for theme in themes:
            rb = tk.Radiobutton(theme_frame, text=theme, variable=self.theme_var, 
                              value=theme, command=self.change_theme)
            rb.pack(anchor='w')
        
        # Настройки обоев
        wallpaper_frame = tk.LabelFrame(parent, text="Обои рабочего стола", 
                                      padx=10, pady=10)
        wallpaper_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Button(wallpaper_frame, text="Выбрать обои", 
                command=self.change_wallpaper).pack(anchor='w', pady=5)
        
        # Цвет акцента
        color_frame = tk.LabelFrame(parent, text="Цвет акцента", padx=10, pady=10)
        color_frame.pack(fill='x', padx=10, pady=5)
        
        self.color_button = tk.Button(color_frame, text="Выбрать цвет", 
                                    command=self.choose_accent_color)
        self.color_button.pack(anchor='w', pady=5)
    
    def create_system_tab(self, parent):
        """Создание вкладки системы"""
        # Информация о системе
        info_frame = tk.LabelFrame(parent, text="Информация о системе", 
                                 padx=10, pady=10)
        info_frame.pack(fill='x', padx=10, pady=5)
        
        info_text = f"""Т-ОС Версия 1.0
Пользователь: {self.os_system.current_user}
Разрешение экрана: {self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}
Архитектура: Python {sys.version.split()[0]}"""

        info_label = tk.Label(info_frame, text=info_text, justify='left')
        info_label.pack(anchor='w')
        
        # Настройки запуска
        startup_frame = tk.LabelFrame(parent, text="Автозагрузка", padx=10, pady=10)
        startup_frame.pack(fill='x', padx=10, pady=5)
        
        self.startup_var = tk.BooleanVar()
        tk.Checkbutton(startup_frame, text="Запускать проводник при входе", 
                     variable=self.startup_var).pack(anchor='w')
        
        # Кнопка обновления
        update_frame = tk.LabelFrame(parent, text="Обновление системы", 
                                   padx=10, pady=10)
        update_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Button(update_frame, text="Проверить обновления", 
                command=self.check_updates).pack(anchor='w', pady=5)
    
    def create_personalization_tab(self, parent):
        """Создание вкладки персонализации"""
        # Имя пользователя
        user_frame = tk.LabelFrame(parent, text="Учетная запись", padx=10, pady=10)
        user_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Label(user_frame, text="Имя пользователя:").pack(anchor='w')
        self.user_entry = tk.Entry(user_frame, width=30)
        self.user_entry.insert(0, self.os_system.current_user)
        self.user_entry.pack(fill='x', pady=5)
        
        tk.Button(user_frame, text="Сохранить", 
                command=self.save_user_name).pack(anchor='w', pady=5)
        
        # Настройки даты и времени
        time_frame = tk.LabelFrame(parent, text="Дата и время", padx=10, pady=10)
        time_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Button(time_frame, text="Настройки времени", 
                command=self.time_settings).pack(anchor='w', pady=5)
    
    def change_theme(self):
        """Изменение темы оформления"""
        theme = self.theme_var.get()
        # Упрощенная реализация смены темы
        colors = {
            "Светлая": {"bg": "white", "fg": "black"},
            "Темная": {"bg": "#1e1e1e", "fg": "white"},
            "Системная": {"bg": "#0078d4", "fg": "white"}
        }
        
        color = colors.get(theme, colors["Темная"])
        # Здесь можно применить тему ко всем компонентам
    
    def change_wallpaper(self):
        """Смена обоев рабочего стола"""
        # В реальной системе здесь был бы выбор файла
        # Для демонстрации - простой выбор цвета
        color = colorchooser.askcolor(title="Выберите цвет обоев")[1]
        if color:
            if hasattr(self.os_system, 'desktop'):
                self.os_system.desktop.canvas.configure(bg=color)
    
    def choose_accent_color(self):
        """Выбор цвета акцента"""
        color = colorchooser.askcolor(title="Выбецвет акцента")[1]
        if color:
            # Применение цвета акцента к элементам интерфейса
            if hasattr(self.os_system, 'taskbar'):
                self.os_system.taskbar.start_button.config(bg=color)
    
    def check_updates(self):
        """Проверка обновлений системы"""
        tk.messagebox.showinfo("Обновления", 
                             "Проверка обновлений...\nТ-ОС обновлена до последней версии.")
    
    def save_user_name(self):
        """Сохранение имени пользователя"""
        new_name = self.user_entry.get()
        if new_name and new_name != self.os_system.current_user:
            self.os_system.current_user = new_name
            tk.messagebox.showinfo("Сохранено", "Имя пользователя изменено")
    
    def time_settings(self):
        """Настройки даты и времени"""
        tk.messagebox.showinfo("Время", 
                             "Текущее время системы: " + 
                             time.strftime("%H:%M:%S %d.%m.%Y"))
    
    def on_close(self):
        """Обработка закрытия окна"""
        self.os_system.unregister_window(self.window)
        self.window.destroy()
    
    def lift(self):
        """Поднять окно на передний план"""
        self.window.lift()