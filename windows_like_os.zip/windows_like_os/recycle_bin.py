# -*- coding: utf-8 -*-
"""
Модуль корзины Т-ОС
Восстановление удаленных файлов
"""

import tkinter as tk
from tkinter import ttk

class RecycleBin:
    """Класс корзины"""
    
    def __init__(self, root, os_system):
        self.root = root
        self.os_system = os_system
        self.deleted_files = []  # Список удаленных файлов
        
        # Создание окна корзины
        self.window = tk.Toplevel(root)
        self.window.title("Корзина - Т-ОС")
        self.window.geometry("600x400")
        
        self.create_content()
        
        # Регистрация в системе
        self.os_system.register_window(self.window)
        self.window.protocol("WM_DELETE_WINDOW", self.on_close)
    
    def create_content(self):
        """Создание содержимого корзины"""
        # Панель инструментов
        toolbar = tk.Frame(self.window, height=40, bg='#f0f0f0')
        toolbar.pack(fill='x')
        toolbar.pack_propagate(False)
        
        restore_btn = tk.Button(toolbar, text="Восстановить", 
                              command=self.restore_selected)
        restore_btn.pack(side='left', padx=5, pady=5)
        
        delete_btn = tk.Button(toolbar, text="Удалить навсегда", 
                             command=self.delete_permanently)
        delete_btn.pack(side='left', padx=5, pady=5)
        
        empty_btn = tk.Button(toolbar, text="Очистить корзину", 
                            command=self.empty_bin)
        empty_btn.pack(side='right', padx=5, pady=5)
        
        # Список удаленных файлов
        list_frame = tk.Frame(self.window)
        list_frame.pack(fill='both', expand=True)
        
        columns = ("name", "original_path", "deleted_date", "size")
        self.files_tree = ttk.Treeview(list_frame, columns=columns, show='headings')
        
        self.files_tree.heading("name", text="Имя файла")
        self.files_tree.heading("original_path", text="Исходный путь")
        self.files_tree.heading("deleted_date", text="Дата удаления")
        self.files_tree.heading("size", text="Размер")
        
        self.files_tree.column("name", width=150)
        self.files_tree.column("original_path", width=200)
        self.files_tree.column("deleted_date", width=120)
        self.files_tree.column("size", width=80)
        
        scrollbar = ttk.Scrollbar(list_frame, orient='vertical', 
                                command=self.files_tree.yview)
        self.files_tree.configure(yscrollcommand=scrollbar.set)
        
        self.files_tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        # Статус бар
        status_bar = tk.Frame(self.window, height=20, bg='#e0e0e0')
        status_bar.pack(fill='x')
        status_bar.pack_propagate(False)
        
        self.status_label = tk.Label(status_bar, text="Корзина пуста", 
                                   bg='#e0e0e0')
        self.status_label.pack(side='left', padx=5)
        
        # Загрузка тестовых данных
        self.load_sample_data()
        self.update_status()
    
    def load_sample_data(self):
        """Загрузка тестовых данных в корзину"""
        import datetime
        
        sample_files = [
            ("Старый документ.txt", "C:\\Документы\\", 
             datetime.datetime.now().strftime("%d.%m.%Y"), "2 KB"),
            ("Ненужное изображение.jpg", "C:\\Изображения\\", 
             datetime.datetime.now().strftime("%d.%m.%Y"), "150 KB"),
            ("Временный файл.tmp", "C:\\Windows\\Temp\\", 
             datetime.datetime.now().strftime("%d.%m.%Y"), "1 KB"),
        ]
        
        for file_info in sample_files:
            self.files_tree.insert("", "end", values=file_info)
            self.deleted_files.append({
                "name": file_info[0],
                "path": file_info[1],
                "data": "Содержимое файла"  # В реальной системе здесь были бы реальные данные
            })
    
    def restore_selected(self):
        """Восстановление выбранного файла"""
        selection = self.files_tree.selection()
        if selection:
            item = selection[0]
            values = self.files_tree.item(item, 'values')
            file_name = values[0]
            
            # Восстановление файла (упрощенная реализация)
            for i, file_data in enumerate(self.deleted_files):
                if file_data["name"] == file_name:
                    # Восстановление в файловой системе
                    restored_path = ["C:", "Восстановленные файлы", file_name]
                    self.os_system._create_file(restored_path, file_data["data"])
                    
                    # Удаление из корзины
                    self.deleted_files.pop(i)
                    self.files_tree.delete(item)
                    break
            
            self.update_status()
            tk.messagebox.showinfo("Восстановление", 
                                 f"Файл '{file_name}' восстановлен в папку 'Восстановленные файлы'")
    
    def delete_permanently(self):
        """Удаление файла навсегда"""
        selection = self.files_tree.selection()
        if selection:
            item = selection[0]
            values = self.files_tree.item(item, 'values')
            file_name = values[0]
            
            # Удаление из списка
            for i, file_data in enumerate(self.deleted_files):
                if file_data["name"] == file_name:
                    self.deleted_files.pop(i)
                    break
            
            self.files_tree.delete(item)
            self.update_status()
    
    def empty_bin(self):
        """Очистка всей корзины"""
        if self.deleted_files:
            result = tk.messagebox.askyesno("Очистка корзины", 
                                          "Вы уверены, что хотите очистить корзину?")
            if result:
                self.deleted_files.clear()
                for item in self.files_tree.get_children():
                    self.files_tree.delete(item)
                self.update_status()
    
    def update_status(self):
        """Обновление статус бара"""
        count = len(self.deleted_files)
        total_size = count * 1  # Упрощенный расчет размера
        
        if count == 0:
            self.status_label.config(text="Корзина пуста")
        else:
            self.status_label.config(text=f"Файлов: {count}, Общий размер: {total_size} KB")
    
    def on_close(self):
        """Обработка закрытия окна"""
        self.os_system.unregister_window(self.window)
        self.window.destroy()
    
    def lift(self):
        """Поднять окно на передний план"""
        self.window.lift()