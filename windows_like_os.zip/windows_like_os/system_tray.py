# -*- coding: utf-8 -*-
"""
Модуль системного трея Т-ОС
Отображение часов, даты и системных уведомлений
"""

import tkinter as tk
import time

class SystemTray:
    """Класс системного трея"""
    
    def __init__(self, root, os_system):
        self.root = root
        self.os_system = os_system
        
        # Данные системного трея
        self.notifications = []
        self.resource_info = "Память: 0%"
    
    def update_resource_info(self, memory_usage):
        """Обновление информации о ресурсах"""
        self.resource_info = f"Память: {memory_usage}%"
        
        # Обновление в панели задач если доступно
        if hasattr(self.os_system, 'taskbar'):
            # Можно добавить отображение в панели задач
            pass
    
    def show_notification(self, title, message):
        """Показать системное уведомление"""
        # Создание всплывающего уведомления
        notification = {
            "title": title,
            "message": message,
            "time": time.strftime("%H:%M:%S")
        }
        self.notifications.append(notification)
        
        # Упрощенное отображение уведомления
        print(f"Уведомление: {title} - {message}")
        
        # В реальной системе здесь было бы всплывающее окно