# -*- coding: utf-8 -*-
"""
Модуль проводника файлов Т-ОС
Отображение файловой системы в виде дерева
"""

import tkinter as tk
from tkinter import ttk

class FileExplorer:
    """Класс проводника файлов"""
    
    def __init__(self, root, os_system, initial_path=None):
        self.root = root
        self.os_system = os_system
        self.current_path = initial_path or ["C:"]
        
        # Создание окна проводника
        self.window = tk.Toplevel(root)
        self.window.title("Проводник - Т-ОС")
        self.window.geometry("800x600")
        
        # Панель инструментов
        self.create_toolbar()
        
        # Основное содержимое
        self.create_content()
        
        # Загрузка файловой системы
        self.load_file_system()
        
        # Регистрация в системе
        self.os_system.register_window(self.window)
        self.window.protocol("WM_DELETE_WINDOW", self.on_close)
    
    def create_toolbar(self):
        """Создание панели инструментов"""
        toolbar = tk.Frame(self.window, bg='#f0f0f0', height=40)
        toolbar.pack(fill='x')
        toolbar.pack_propagate(False)
        
        # Кнопки навигации
        back_btn = tk.Button(toolbar, text="←", command=self.go_back)
        back_btn.pack(side='left', padx=2, pady=2)
        
        forward_btn = tk.Button(toolbar, text="→", command=self.go_forward)
        forward_btn.pack(side='left', padx=2, pady=2)
        
        up_btn = tk.Button(toolbar, text="↑", command=self.go_up)
        up_btn.pack(side='left', padx=2, pady=2)
        
        # Адресная строка
        self.address_bar = tk.Entry(toolbar)
        self.address_bar.pack(side='left', fill='x', expand=True, padx=5, pady=2)
        self.address_bar.bind('<Return>', self.navigate_to_address)
        
        # Кнопка обновления
        refresh_btn = tk.Button(toolbar, text="⟳", command=self.refresh)
        refresh_btn.pack(side='right', padx=2, pady=2)
    
    def create_content(self):
        """Создание основного содержимого проводника"""
        main_frame = tk.Frame(self.window)
        main_frame.pack(fill='both', expand=True)
        
        # Дерево папок слева
        self.tree_frame = tk.Frame(main_frame, width=200, bg='white')
        self.tree_frame.pack(side='left', fill='y')
        self.tree_frame.pack_propagate(False)
        
        self.tree = ttk.Treeview(self.tree_frame)
        self.tree.pack(fill='both', expand=True, padx=5, pady=5)
        self.tree.bind('<<TreeviewSelect>>', self.on_tree_select)
        
        # Содержимое папки справа
        self.content_frame = tk.Frame(main_frame, bg='white')
        self.content_frame.pack(side='right', fill='both', expand=True)
        
        # Список файлов
        self.file_list = tk.Listbox(self.content_frame, font=('Arial', 11))
        self.file_list.pack(fill='both', expand=True, padx=5, pady=5)
        self.file_list.bind('<Double-Button-1>', self.on_file_double_click)
        
        # Контекстное меню
        self.context_menu = tk.Menu(self.window, tearoff=0)
        self.context_menu.add_command(label="Открыть", command=self.open_selected)
        self.context_menu.add_command(label="Удалить", command=self.delete_selected)
        self.context_menu.add_command(label="Переименовать", command=self.rename_selected)
        self.context_menu.add_command(label="Создать папку", command=self.create_folder)
        
        self.file_list.bind('<Button-3>', self.show_context_menu)
    
    def load_file_system(self):
        """Загрузка файловой системы в дерево"""
        self.tree.delete(*self.tree.get_children())
        
        def add_node(parent, path, data):
            for name, item_data in data.items():
                if isinstance(item_data, dict) and item_data.get('type') == 'folder':
                    node = self.tree.insert(parent, 'end', text=name, values=[name])
                    if 'content' in item_data:
                        add_node(node, path + [name], item_data['content'])
                else:
                    self.tree.insert(parent, 'end', text=name, values=[name])
        
        add_node('', [], self.os_system.file_system)
        
        # Обновление содержимого текущей папки
        self.update_content()
    
    def update_content(self):
        """Обновление содержимого текущей папки"""
        self.file_list.delete(0, tk.END)
        
        # Получение текущей папки
        current_folder = self.os_system.file_system
        for folder in self.current_path:
            if folder in current_folder:
                current_folder = current_folder[folder]
                if 'content' in current_folder:
                    current_folder = current_folder['content']
        
        # Добавление файлов и папок в список
        for name, item_data in current_folder.items():
            if isinstance(item_data, dict) and item_data.get('type') == 'folder':
                self.file_list.insert(tk.END, f"[Папка] {name}")
            else:
                self.file_list.insert(tk.END, f"[Файл] {name}")
        
        # Обновление адресной строки
        self.address_bar.delete(0, tk.END)
        self.address_bar.insert(0, "\\".join(self.current_path))
    
    def on_tree_select(self, event):
        """Обработка выбора в дереве папок"""
        selection = self.tree.selection()
        if selection:
            item = selection[0]
            path = [self.tree.item(item, "text")]
            parent = self.tree.parent(item)
            
            while parent:
                path.insert(0, self.tree.item(parent, "text"))
                parent = self.tree.parent(parent)
            
            self.current_path = path
            self.update_content()
    
    def on_file_double_click(self, event):
        """Обработка двойного клика по файлу"""
        selection = self.file_list.curselection()
        if selection:
            filename = self.file_list.get(selection[0])
            # Удаление префикса [Папка] или [Файл]
            clean_name = filename.split('] ')[1] if '] ' in filename else filename
            
            if filename.startswith("[Папка]"):
                # Переход в папку
                self.current_path.append(clean_name)
                self.update_content()
            else:
                # Открытие файла
                self.open_file(clean_name)
    
    def open_file(self, filename):
        """Открытие файла"""
        file_path = self.current_path + [filename]
        content = self.get_file_content(file_path)
        
        # Открытие в блокноте
        self.os_system.open_notepad()
        # Здесь можно передать содержимое файла в блокнот
    
    def get_file_content(self, path):
        """Получение содержимого файла"""
        current = self.os_system.file_system
        for item in path:
            if item in current:
                current = current[item]
                if 'content' in current:
                    current = current['content']
        
        return current.get('content', '') if isinstance(current, dict) else ''
    
    def show_context_menu(self, event):
        """Показать контекстное меню"""
        self.context_menu.post(event.x_root, event.y_root)
    
    def go_back(self):
        """Назад"""
        if len(self.current_path) > 1:
            self.current_path.pop()
            self.update_content()
    
    def go_forward(self):
        """Вперед (упрощенная реализация)"""
        # В реальной системе здесь была бы история навигации
        pass
    
    def go_up(self):
        """Вверх на один уровень"""
        if len(self.current_path) > 1:
            self.current_path.pop()
            self.update_content()
    
    def navigate_to_address(self, event):
        """Навигация по адресной строке"""
        address = self.address_bar.get()
        if address:
            self.current_path = address.split('\\')
            self.update_content()
    
    def refresh(self):
        """Обновить содержимое"""
        self.update_content()
    
    def open_selected(self):
        """Открыть выбранный элемент"""
        self.on_file_double_click(None)
    
    def delete_selected(self):
        """Удалить выбранный элемент"""
        selection = self.file_list.curselection()
        if selection:
            filename = self.file_list.get(selection[0])
            clean_name = filename.split('] ')[1] if '] ' in filename else filename
            
            # Перемещение в корзину
            self.move_to_recycle_bin(clean_name)
    
    def move_to_recycle_bin(self, filename):
        """Перемещение файла в корзину"""
        # Упрощенная реализация - просто удаление
        current_folder = self.os_system.file_system
        for folder in self.current_path:
            if folder in current_folder:
                current_folder = current_folder[folder]
                if 'content' in current_folder:
                    current_folder = current_folder['content']
        
        if filename in current_folder:
            del current_folder[filename]
            self.update_content()
    
    def rename_selected(self):
        """Переименовать выбранный элемент"""
        selection = self.file_list.curselection()
        if selection:
            # Простая реализация переименования
            pass
    
    def create_folder(self):
        """Создать новую папку"""
        folder_name = "Новая папка"
        current_folder = self.os_system.file_system
        for folder in self.current_path:
            if folder in current_folder:
                current_folder = current_folder[folder]
                if 'content' in current_folder:
                    current_folder = current_folder['content']
        
        # Проверка на существование
        counter = 1
        temp_name = folder_name
        while temp_name in current_folder:
            temp_name = f"{folder_name} ({counter})"
            counter += 1
        
        current_folder[temp_name] = {"type": "folder", "content": {}}
        self.update_content()
    
    def on_close(self):
        """Обработка закрытия окна"""
        self.os_system.unregister_window(self.window)
        self.window.destroy()
    
    def lift(self):
        """Поднять окно на передний план"""
        self.window.lift()