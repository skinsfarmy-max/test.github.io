# -*- coding: utf-8 -*-
"""
Модуль меню Пуск Т-ОС
Выпадающее меню с приложениями, поиском и кнопкой выключения
"""

import tkinter as tk
from tkinter import ttk

class StartMenu:
    """Класс меню Пуск"""
    
    def __init__(self, root, os_system):
        self.root = root
        self.os_system = os_system
        self.visible = False
        
        # Создание окна меню Пуск
        self.window = tk.Toplevel(root)
        self.window.overrideredirect(True)  # Без рамки
        self.window.configure(bg='#1e1e1e')
        self.window.withdraw()  # Скрыть initially
        
        # Позиционирование в левом нижнем углу
        self.update_position()
        
        # Содержимое меню
        self.create_content()
        
        # Привязка событий
        self.window.bind("<FocusOut>", self.on_focus_out)
        root.bind("<Button-1>", self.check_click_outside)
    
    def update_position(self):
        """Обновление позиции меню"""
        # Позиция рядом с кнопкой Пуск
        x = 10
        y = self.root.winfo_height() - 340  # Высота меню
        self.window.geometry(f"300x340+{x}+{y}")
    
    def create_content(self):
        """Создание содержимого меню Пуск"""
        # Заголовок
        header = tk.Frame(self.window, bg='#0078d4', height=60)
        header.pack(fill='x')
        header.pack_propagate(False)
        
        tk.Label(header, text="Т-ОС", font=('Arial', 16, 'bold'), 
                bg='#0078d4', fg='white').pack(anchor='w', padx=15, pady=10)
        
        # Поиск
        search_frame = tk.Frame(self.window, bg='#2d2d2d', height=40)
        search_frame.pack(fill='x', padx=10, pady=10)
        search_frame.pack_propagate(False)
        
        search_entry = tk.Entry(search_frame, bg='#3c3c3c', fg='white', 
                              insertbackground='white', relief='flat')
        search_entry.pack(fill='both', expand=True, padx=5, pady=5)
        search_entry.insert(0, "Поиск в Т-ОС")
        
        # Список приложений
        apps_frame = tk.Frame(self.window, bg='#1e1e1e')
        apps_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Приложения
        applications = [
            ("Проводник", self.os_system.open_file_explorer),
            ("Диспетчер задач", self.os_system.open_task_manager),
            ("Корзина", self.os_system.open_recycle_bin),
            ("Настройки", self.os_system.open_settings),
            ("Блокнот", self.os_system.open_notepad),
            ("Калькулятор", self.os_system.open_calculator),
        ]
        
        for name, command in applications:
            app_btn = tk.Button(apps_frame, text=name, anchor='w',
                              bg='#1e1e1e', fg='white', bd=0,
                              font=('Arial', 11),
                              command=command)
            app_btn.pack(fill='x', pady=2)
            
            # Эффекты наведения
            app_btn.bind("<Enter>", lambda e, b=app_btn: b.config(bg='#0078d4'))
            app_btn.bind("<Leave>", lambda e, b=app_btn: b.config(bg='#1e1e1e'))
        
        # Нижняя панель с кнопкой выключения
        footer = tk.Frame(self.window, bg='#2d2d2d', height=50)
        footer.pack(fill='x')
        footer.pack_propagate(False)
        
        power_btn = tk.Button(footer, text="⚡", font=('Arial', 16),
                            bg='#2d2d2d', fg='white', bd=0,
                            command=self.os_system._shutdown_dialog)
        power_btn.pack(side='right', padx=10, pady=10)
    
    def toggle(self):
        """Переключение видимости меню Пуск"""
        if self.visible:
            self.hide()
        else:
            self.show()
    
    def show(self):
        """Показать меню Пуск"""
        self.update_position()
        self.window.deiconify()
        self.window.lift()
        self.visible = True
        
        # Регистрация в системе
        self.os_system.register_window(self.window)
    
    def hide(self):
        """Скрыть меню Пуск"""
        self.window.withdraw()
        self.visible = False
        
        # Удаление из системы
        self.os_system.unregister_window(self.window)
    
    def on_focus_out(self, event):
        """Скрыть меню при потере фокуса"""
        if self.visible:
            self.hide()
    
    def check_click_outside(self, event):
        """Проверка клика вне меню"""
        if (self.visible and 
            not self.window.winfo_containing(event.x_root, event.y_root)):
            self.hide()