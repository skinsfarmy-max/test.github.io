#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Главный модуль Т-ОС (Т-ОС)
Основная точка входа в операционную систему
"""

import tkinter as tk
from tkinter import messagebox
import sys
import os
import threading
import time

# Импорт модулей системы
from desktop import Desktop
from taskbar import Taskbar
from start_menu import StartMenu
from file_explorer import FileExplorer
from task_manager import TaskManager
from recycle_bin import RecycleBin
from settings import Settings
from system_tray import SystemTray

class TOS:
    """Основной класс операционной системы Т-ОС"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Т-ОС v1.0")
        self.root.geometry("1024x768")
        self.root.configure(bg='black')
        
        # Полноэкранный режим
        self.root.attributes('-fullscreen', True)
        self.fullscreen = True
        
        # Переменные системы
        self.open_windows = []
        self.active_window = None
        self.processes = []
        self.file_system = {}
        self.current_user = "Пользователь"
        
        # Инициализация файловой системы
        self._init_file_system()
        
        # Загрузка компонентов
        self._load_components()
        
        # Регистрация горячих клавиш
        self._register_hotkeys()
        
        # Мониторинг ресурсов
        self._start_resource_monitor()
    
    def _init_file_system(self):
        """Инициализация виртуальной файловой системы"""
        self.file_system = {
            "C:": {
                "Пользователи": {
                    self.current_user: {
                        "Рабочий стол": {"type": "folder", "content": {}},
                        "Документы": {"type": "folder", "content": {}},
                        "Загрузки": {"type": "folder", "content": {}},
                    }
                },
                "Windows": {
                    "System32": {"type": "folder", "content": {}},
                    "Temp": {"type": "folder", "content": {}}
                },
                "Program Files": {"type": "folder", "content": {}}
            }
        }
        
        # Создание нескольких тестовых файлов
        desktop_path = ["C:", "Пользователи", self.current_user, "Рабочий стол"]
        self._create_file(desktop_path + ["Приветствие.txt"], 
                         "Добро пожаловать в Т-ОС!")
    
    def _create_file(self, path, content=""):
        """Создание файла в файловой системе"""
        current = self.file_system
        for folder in path[:-1]:
            if folder not in current:
                current[folder] = {"type": "folder", "content": {}}
            current = current[folder].get("content", current[folder])
        
        filename = path[-1]
        current[filename] = {"type": "file", "content": content}
    
    def _load_components(self):
        """Загрузка всех компонентов системы"""
        try:
            # Рабочий стол
            self.desktop = Desktop(self.root, self)
            
            # Панель задач
            self.taskbar = Taskbar(self.root, self)
            
            # Системный трей
            self.system_tray = SystemTray(self.root, self)
            
            # Инициализация других компонентов (создаются по требованию)
            self.start_menu = None
            self.file_explorer = None
            self.task_manager = None
            self.recycle_bin = None
            self.settings = None
            
            print("Т-ОС: Все компоненты загружены успешно")
            
        except Exception as e:
            messagebox.showerror("Ошибка загрузки", f"Ошибка при загрузке системы: {str(e)}")
            sys.exit(1)
    
    def _register_hotkeys(self):
        """Регистрация глобальных горячих клавиш"""
        self.root.bind('<Alt-F4>', self._shutdown_dialog)
        self.root.bind('<Alt-Tab>', self._switch_window)
        self.root.bind('<Control-Shift-Escape>', self._open_task_manager)
        self.root.bind('<Super_R>', self._open_run_dialog)  # Win+R
        self.root.bind('<Escape>', self._toggle_fullscreen)
        self.root.bind('<F1>', self._show_help)
    
    def _shutdown_dialog(self, event=None):
        """Диалог выключения системы"""
        result = messagebox.askyesno("Выключение Т-ОС", 
                                   "Вы уверены, что хотите выключить Т-ОС?",
                                   icon='warning')
        if result:
            self.shutdown()
    
    def _switch_window(self, event=None):
        """Переключение между окнами (Alt+Tab)"""
        if len(self.open_windows) > 1:
            # Простая реализация переключения окон
            if self.active_window:
                index = self.open_windows.index(self.active_window)
                next_index = (index + 1) % len(self.open_windows)
                self.focus_window(self.open_windows[next_index])
    
    def _open_task_manager(self, event=None):
        """Открытие диспетчера задач (Ctrl+Shift+Esc)"""
        self.open_task_manager()
    
    def _open_run_dialog(self, event=None):
        """Открытие диалога Выполнить (Win+R)"""
        self.open_run_dialog()
    
    def _toggle_fullscreen(self, event=None):
        """Переключение полноэкранного режима (Esc)"""
        self.fullscreen = not self.fullscreen
        self.root.attributes('-fullscreen', self.fullscreen)
    
    def _show_help(self, event=None):
        """Показать справку (F1)"""
        help_text = """Т-ОС - Операционная система на Python

Горячие клавиши:
- Alt+F4: Выключение
- Alt+Tab: Переключение окон
- Ctrl+Shift+Esc: Диспетчер задач
- Win+R: Выполнить
- Esc: Выход из полноэкранного режима
- F1: Справка

Разработано на Python 3.x с Tkinter"""
        messagebox.showinfo("Справка Т-ОС", help_text)
    
    def _start_resource_monitor(self):
        """Запуск мониторинга ресурсов в отдельном потоке"""
        def monitor():
            while True:
                # Мониторинг использования памяти
                import psutil
                memory_usage = psutil.virtual_memory().percent
                # Обновление информации в системном трее
                if hasattr(self, 'system_tray'):
                    self.system_tray.update_resource_info(memory_usage)
                time.sleep(5)
        
        # Запуск в отдельном потоке
        monitor_thread = threading.Thread(target=monitor, daemon=True)
        monitor_thread.start()
    
    # Методы управления окнами
    def register_window(self, window):
        """Регистрация нового окна в системе"""
        if window not in self.open_windows:
            self.open_windows.append(window)
            if hasattr(self, 'taskbar'):
                self.taskbar.update_taskbar()
    
    def unregister_window(self, window):
        """Удаление окна из системы"""
        if window in self.open_windows:
            self.open_windows.remove(window)
            if hasattr(self, 'taskbar'):
                self.taskbar.update_taskbar()
    
    def focus_window(self, window):
        """Активация окна"""
        self.active_window = window
        try:
            if hasattr(window, 'focus'):
                window.focus()
            elif hasattr(window, 'lift'):
                window.lift()
        except:
            pass
    
    # Методы открытия системных приложений
    def open_start_menu(self):
        """Открытие меню Пуск"""
        if not self.start_menu or not self.start_menu.window.winfo_exists():
            from start_menu import StartMenu
            self.start_menu = StartMenu(self.root, self)
        self.start_menu.toggle()
    
    def open_file_explorer(self, path=None):
        """Открытие проводника"""
        if not self.file_explorer or not self.file_explorer.window.winfo_exists():
            from file_explorer import FileExplorer
            self.file_explorer = FileExplorer(self.root, self, path)
        else:
            self.file_explorer.lift()
    
    def open_task_manager(self):
        """Открытие диспетчера задач"""
        if not self.task_manager or not self.task_manager.window.winfo_exists():
            from task_manager import TaskManager
            self.task_manager = TaskManager(self.root, self)
        else:
            self.task_manager.lift()
    
    def open_recycle_bin(self):
        """Открытие корзины"""
        if not self.recycle_bin or not self.recycle_bin.window.winfo_exists():
            from recycle_bin import RecycleBin
            self.recycle_bin = RecycleBin(self.root, self)
        else:
            self.recycle_bin.lift()
    
    def open_settings(self):
        """Открытие настроек"""
        if not self.settings or not self.settings.window.winfo_exists():
            from settings import Settings
            self.settings = Settings(self.root, self)
        else:
            self.settings.lift()
    
    def open_run_dialog(self):
        """Открытие диалога Выполнить"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Выполнить")
        dialog.geometry("300x120")
        dialog.transient(self.root)
        dialog.grab_set()
        
        tk.Label(dialog, text="Введите команду:").pack(pady=10)
        entry = tk.Entry(dialog, width=30)
        entry.pack(pady=5)
        entry.focus()
        
        def execute():
            command = entry.get().lower()
            if command in ['explorer', 'проводник']:
                self.open_file_explorer()
            elif command in ['taskmgr', 'диспетчер']:
                self.open_task_manager()
            elif command in ['calc', 'калькулятор']:
                self.open_calculator()
            elif command in ['notepad', 'блокнот']:
                self.open_notepad()
            dialog.destroy()
        
        tk.Button(dialog, text="Выполнить", command=execute).pack(pady=5)
        entry.bind('<Return>', lambda e: execute())
    
    def open_calculator(self):
        """Открытие калькулятора"""
        calc_window = tk.Toplevel(self.root)
        calc_window.title("Калькулятор")
        calc_window.geometry("300x400")
        
        # Простой калькулятор
        display = tk.Entry(calc_window, font=('Arial', 14), justify='right')
        display.pack(fill='x', padx=10, pady=10)
        
        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            '0', '.', '=', '+'
        ]
        
        def button_click(char):
            if char == '=':
                try:
                    result = eval(display.get())
                    display.delete(0, tk.END)
                    display.insert(0, str(result))
                except:
                    display.delete(0, tk.END)
                    display.insert(0, "Ошибка")
            else:
                display.insert(tk.END, char)
        
        frame = tk.Frame(calc_window)
        frame.pack(padx=10, pady=10)
        
        for i, char in enumerate(buttons):
            btn = tk.Button(frame, text=char, width=5, height=2,
                          command=lambda c=char: button_click(c))
            btn.grid(row=i//4, column=i%4, padx=2, pady=2)
        
        self.register_window(calc_window)
        calc_window.protocol("WM_DELETE_WINDOW", 
                           lambda: self.unregister_window(calc_window))
    
    def open_notepad(self):
        """Открытие блокнота"""
        notepad_window = tk.Toplevel(self.root)
        notepad_window.title("Блокнот - Т-ОС")
        notepad_window.geometry("600x400")
        
        text_area = tk.Text(notepad_window, wrap='word')
        scrollbar = tk.Scrollbar(notepad_window, command=text_area.yview)
        text_area.configure(yscrollcommand=scrollbar.set)
        
        text_area.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        self.register_window(notepad_window)
        notepad_window.protocol("WM_DELETE_WINDOW", 
                              lambda: self.unregister_window(notepad_window))
    
    def shutdown(self):
        """Корректное выключение системы"""
        print("Т-ОС: Завершение работы...")
        
        # Закрытие всех окон
        for window in self.open_windows[:]:
            try:
                window.destroy()
            except:
                pass
        
        # Сохранение состояния системы
        self._save_system_state()
        
        print("Т-ОС: Работа завершена.")
        self.root.quit()
        sys.exit(0)
    
    def _save_system_state(self):
        """Сохранение состояния системы (заглушка)"""
        print("Т-ОС: Сохранение состояния системы...")
    
    def run(self):
        """Запуск операционной системы"""
        print("Т-ОС: Запуск системы...")
        try:
            self.root.mainloop()
        except KeyboardInterrupt:
            self.shutdown()
        except Exception as e:
            messagebox.showerror("Критическая ошибка", f"Системная ошибка: {str(e)}")
            sys.exit(1)

if __name__ == "__main__":
    # Проверка версии Python
    if sys.version_info < (3, 6):
        print("Требуется Python 3.6 или выше")
        sys.exit(1)
    
    # Запуск ОС
    os_system = TOS()
    os_system.run()