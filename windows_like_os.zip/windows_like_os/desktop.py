# -*- coding: utf-8 -*-
"""
Модуль рабочего стола Т-ОС
Отображает обои, ярлыки приложений и файлы
"""

import tkinter as tk
from tkinter import ttk
import os
import json

class Desktop:
    """Класс рабочего стола"""
    
    def __init__(self, root, os_system):
        self.root = root
        self.os_system = os_system
        self.icons = []
        self.selected_icon = None
        
        # Создание canvas для рабочего стола
        self.canvas = tk.Canvas(root, bg='#0078d4', highlightthickness=0)
        self.canvas.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Установка обоев
        self.set_wallpaper()
        
        # Создание ярлыков на рабочем столе
        self.create_shortcuts()
        
        # Привязка событий мыши
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<Double-Button-1>", self.on_double_click)
        self.canvas.bind("<Button-3>", self.show_context_menu)
    
    def set_wallpaper(self, wallpaper_path=None):
        """Установка обоев рабочего стола"""
        # Простые градиентные обои (синий градиент как в Windows)
        self.canvas.configure(bg='#0078d4')
        
        # Можно добавить изображение, но для простоты используем градиент
        try:
            # Создание градиента
            width = self.root.winfo_screenwidth()
            height = self.root.winfo_screenheight()
            
            for i in range(height):
                # Простой вертикальный градиент
                color = self._get_gradient_color(i, height)
                self.canvas.create_line(0, i, width, i, fill=color)
        except:
            pass
    
    def _get_gradient_color(self, position, max_position):
        """Генерация цвета градиента"""
        # От темно-синего к синему
        r1, g1, b1 = 0, 90, 158  # Темно-синий
        r2, g2, b2 = 0, 120, 215  # Синий
        
        ratio = position / max_position
        r = int(r1 + (r2 - r1) * ratio)
        g = int(g1 + (g2 - g1) * ratio)
        b = int(b1 + (b2 - b1) * ratio)
        
        return f'#{r:02x}{g:02x}{b:02x}'
    
    def create_shortcuts(self):
        """Создание ярлыков на рабочем столе"""
        shortcuts = [
            {"name": "Проводник", "command": self.os_system.open_file_explorer, "x": 50, "y": 50},
            {"name": "Корзина", "command": self.os_system.open_recycle_bin, "x": 50, "y": 120},
            {"name": "Настройки", "command": self.os_system.open_settings, "x": 50, "y": 190},
            {"name": "Блокнот", "command": self.os_system.open_notepad, "x": 50, "y": 260},
            {"name": "Калькулятор", "command": self.os_system.open_calculator, "x": 50, "y": 330},
        ]
        
        for shortcut in shortcuts:
            self.create_icon(shortcut["name"], shortcut["command"], 
                           shortcut["x"], shortcut["y"])
    
    def create_icon(self, name, command, x, y):
        """Создание значка на рабочем столе"""
        # Фон значка
        icon_bg = self.canvas.create_rectangle(x-40, y-40, x+40, y+40, 
                                             fill='white', outline='lightgray', width=1)
        
        # Упрощенная иконка (квадрат с цветом)
        colors = {'Проводник': 'blue', 'Корзина': 'red', 'Настройки': 'green', 
                 'Блокнот': 'yellow', 'Калькулятор': 'purple'}
        color = colors.get(name, 'gray')
        
        icon_shape = self.canvas.create_rectangle(x-20, y-20, x+20, y+20, 
                                                fill=color, outline='darkgray')
        
        # Текст под иконкой
        icon_text = self.canvas.create_text(x, y+50, text=name, font=('Arial', 10),
                                          fill='white')
        
        # Сохранение информации об иконке
        icon_data = {
            'bg': icon_bg,
            'shape': icon_shape,
            'text': icon_text,
            'x': x, 'y': y,
            'command': command,
            'name': name
        }
        
        self.icons.append(icon_data)
        
        # Привязка событий к иконке
        for item in [icon_bg, icon_shape, icon_text]:
            self.canvas.tag_bind(item, "<Button-1>", 
                               lambda e, cmd=command: self.on_icon_click(e, cmd))
            self.canvas.tag_bind(item, "<Double-Button-1>", 
                               lambda e, cmd=command: self.on_icon_double_click(e, cmd))
    
    def on_icon_click(self, event, command):
        """Обработка клика по иконке"""
        # Сброс предыдущего выделения
        if self.selected_icon:
            self.canvas.itemconfig(self.selected_icon['bg'], outline='lightgray')
        
        # Находим иконку по координатам
        for icon in self.icons:
            if (abs(event.x - icon['x']) < 40 and 
                abs(event.y - icon['y']) < 40):
                self.selected_icon = icon
                self.canvas.itemconfig(icon['bg'], outline='yellow', width=2)
                break
    
    def on_icon_double_click(self, event, command):
        """Обработка двойного клика по иконке"""
        command()
    
    def on_click(self, event):
        """Обработка клика по рабочему столу"""
        # Сброс выделения иконки
        if self.selected_icon:
            self.canvas.itemconfig(self.selected_icon['bg'], outline='lightgray')
            self.selected_icon = None
    
    def on_double_click(self, event):
        """Обработка двойного клика по рабочему столу"""
        # Открытие проводника при двойном клике на пустом месте
        if not self.selected_icon:
            self.os_system.open_file_explorer()
    
    def show_context_menu(self, event):
        """Показать контекстное меню рабочего стола"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="Обновить", command=self.refresh)
        menu.add_command(label="Создать папку", command=self.create_folder)
        menu.add_command(label="Создать файл", command=self.create_file)
        menu.add_separator()
        menu.add_command(label="Настройки экрана", command=self.os_system.open_settings)
        
        menu.post(event.x_root, event.y_root)
    
    def refresh(self):
        """Обновить рабочий стол"""
        # В реальной системе здесь была бы перезагрузка значков
        print("Рабочий стол обновлен")
    
    def create_folder(self):
        """Создать новую папку на рабочем столе"""
        # Простая реализация - создание в файловой системе
        desktop_path = ["C:", "Пользователи", self.os_system.current_user, "Рабочий стол"]
        folder_name = "Новая папка"
        
        # Добавление номера если папка уже существует
        counter = 1
        temp_name = folder_name
        current_path = self.os_system.file_system
        for folder in desktop_path:
            current_path = current_path[folder].get("content", current_path[folder])
        
        while temp_name in current_path:
            temp_name = f"{folder_name} ({counter})"
            counter += 1
        
        current_path[temp_name] = {"type": "folder", "content": {}}
        
        # Создание значка на рабочем столе
        x, y = 100 + (len(self.icons) * 80) % 600, 100 + (len(self.icons) // 8) * 100
        self.create_icon(temp_name, 
                        lambda p=desktop_path + [temp_name]: self.os_system.open_file_explorer(p),
                        x, y)
    
    def create_file(self):
        """Создать новый файл на рабочем столе"""
        desktop_path = ["C:", "Пользователи", self.os_system.current_user, "Рабочий стол"]
        file_name = "Новый файл.txt"
        
        counter = 1
        temp_name = file_name
        current_path = self.os_system.file_system
        for folder in desktop_path:
            current_path = current_path[folder].get("content", current_path[folder])
        
        while temp_name in current_path:
            temp_name = f"Новый файл ({counter}).txt"
            counter += 1
        
        self.os_system._create_file(desktop_path + [temp_name], "Содержимое нового файла")
        
        # Создание значка
        x, y = 100 + (len(self.icons) * 80) % 600, 100 + (len(self.icons) // 8) * 100
        self.create_icon(temp_name, 
                        lambda: self.open_file(desktop_path + [temp_name]),
                        x, y)
    
    def open_file(self, file_path):
        """Открытие файла"""
        # Простая реализация - открытие в блокноте
        content = self.get_file_content(file_path)
        self.os_system.open_notepad()
        # Здесь можно передать содержимое в блокнот