// ==UserScript==
// @name         Изменение заголовков заданий
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Изменяет заголовки с "Домашнее задание" на "Практическая работа" и класс с two на five
// @author       You
// @match        https://sgo.mari-el.gov.ru/app/school/studentdiary/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';
    
    function modifyElements() {
        document.querySelectorAll('a[title="Домашнее задание"].two').forEach(element => {
            element.setAttribute('title', 'Практическая работа');
            element.classList.remove('two');
            element.classList.add('five');
        });
    }
    
    // Запускаем сразу после загрузки DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', modifyElements);
    } else {
        modifyElements();
    }
    
    // Для динамического контента (если страница подгружает контент через AJAX)
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length) {
                modifyElements();
            }
        });
    });
    
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();